/*  macros for fold() routine */

typedef enum {
	FOLDUP, FOLDDOWN} 
FOLDMODE;

char *fold(),*foldup(),*folddown();
